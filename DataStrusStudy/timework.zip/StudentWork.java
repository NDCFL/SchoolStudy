package T6;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;

import com.sun.org.apache.xml.internal.security.utils.IgnoreAllErrorHandler;

public class StudentWork extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTable table;
	JScrollPane js;
	JButton bu,buto,close,update,delete,timein,closeclass;
	JLabel lb1,lb2,lbname,lbtel,lbsex,lbmath,lbenglish;
	JTextField text,name,tel,math,english;
	JRadioButton man,weman;
	JTableHeader head;
	ButtonGroup bg;
	JPanel panel;
	String title[]={"学号","姓名","性别","高数出勤","大英出勤","出勤得分"};
	String data[][]=new String[90][6];
	String value[][];
	String temp[]= new String[6];
	static int row=0;
	public StudentWork() {
		setTitle("学生考勤管理");
		readfile();
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image image = toolkit.getImage("time.png");
		setIconImage(image);
		//界面的控件布局
		panel = new JPanel(null);
		table = new JTable(data,title);
		table.setBounds(0, 50, 500, 300);
		table.setRowHeight(30);
		table.setFont(new Font("楷体",Font.BOLD,16));
		
		//滚动面板
		js = new JScrollPane(table);
		js.setBounds(0,50,780, 292);
		
		panel.add(js);
		
		lb1 = new JLabel("学生考勤子系统");
		lb1.setBounds(320, 10, 200, 30);
		lb1.setFont(new Font("楷体",Font.BOLD,24));
		panel.add(lb1);
		
		lbname = new JLabel("学号");
		lbname.setBounds(30, 360, 30, 30);
		panel.add(lbname);
		
		name = new JTextField();
		name.setBounds(80, 360, 60, 30);
		panel.add(name);
		
		lbtel = new JLabel("姓名");
		lbtel.setBounds(160, 360, 30, 30);
		panel.add(lbtel);
		
		tel = new JTextField();
		tel.setBounds(200, 360, 60, 30);
		panel.add(tel);
		
		lbsex = new JLabel("性别");
		lbsex.setBounds(280, 360, 60, 30);
		panel.add(lbsex);
		
		man = new JRadioButton("男",true);
		man.setBounds(320, 360, 40, 30);
		panel.add(man);
		
		weman = new JRadioButton("女",false);
		weman.setBounds(370, 360, 40, 30);
		panel.add(weman);
		
		bg = new ButtonGroup();
		bg.add(man);
		bg.add(weman);
		
		lbmath = new JLabel("高数出勤");
		lbmath.setBounds(420, 360, 60, 30);
		panel.add(lbmath);
		
		math = new JTextField();
		math.setBounds(480, 360, 80, 30);
		panel.add(math);
		
		lbenglish = new JLabel("大英出勤");
		lbenglish.setBounds(570, 360, 60, 30);
		panel.add(lbenglish);
		
		english = new JTextField();
		english.setBounds(640, 360, 80, 30);
		panel.add(english);
		
		buto = new JButton("新增/修改");
		buto.setBounds(30, 400, 100, 30);
		panel.add(buto);

		bu = new JButton("查找");
		bu.setBounds(470, 400, 80, 30);
		panel.add(bu);
		
		update = new JButton("修改");
		update.setBounds(330, 400, 80, 30);
		panel.add(update);
		
		delete = new JButton("删除");
		delete.setBounds(190, 400, 80, 30);
		panel.add(delete);
		
		timein = new JButton("出勤统计");
		timein.setBounds(600, 400, 120, 30);
		panel.add(timein);
		
		
		delete.addActionListener(this);
		update.addActionListener(this);
		bu.addActionListener(this);
		buto.addActionListener(this);
		timein.addActionListener(this);
		add(panel);
		setSize(800, 500);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new StudentWork();
	}
	public void readfile(){
		try {
			File file = new File("timework.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String string = "";
			String str="";
			String Tel[]={};
			while ((string=br.readLine())!=null) {
				str+=string+";";
				Tel = str.split(";");
			}
			value = new String[Tel.length][6];
			for(int i=0;i<Tel.length;i++){
				value[i]=Tel[i].split(",");
				data[i]=Tel[i].split(",");
				System.out.println(data[i][0]+"-----");
			}
			br.close();
			file=null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bu){
			String nameid = name.getText();
			for(int i=0;i<value.length;i++){
				for(int j=0;j<value[i].length;j++){
					if(value[i][0].equals(nameid)){
						row++;
						table.setRowSelectionInterval(i,i);
						JOptionPane.showMessageDialog(this, "查询成功，已经为你高亮显示");
						return;
					}else if (value[i][1].equals(tel.getText())) {
						row++;
						table.setRowSelectionInterval(i,i);
						JOptionPane.showMessageDialog(this, "查询成功，已经为你高亮显示");
						return;
					}
				}
			}
			JOptionPane.showMessageDialog(this, "无此人");
			return;
		}else if(e.getSource()==buto){
			if(name.getText().equals("")){
				JOptionPane.showMessageDialog(this, "姓名为空");
				return;
			}else if (tel.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Tel为空");
				return;
			}else if (math.getText()!=null) {
				try{
					int num = Integer.parseInt(math.getText());
				}catch (Exception e1) {
					JOptionPane.showMessageDialog(this, "高数评分输入有误！");
				}
			}else if (english.getText()!=null) {
				try{
					int num = Integer.parseInt(math.getText());
				}catch (Exception e1) {
					JOptionPane.showMessageDialog(this, "大英评分输入有误！");
				}
			}
			File file = new File("timework.txt");
			try {
				FileOutputStream fos = new FileOutputStream(file,true);
				
				String sex="";
				if(man.isSelected()){
					sex="男";
				}else {
					sex="女";
				}
				String string = name.getText()+","+tel.getText()+","+sex+","+math.getText()+","+english.getText()+",未评分;";
				byte b[]=string.getBytes();
				if(temp[5]==null || temp[5].equals("")){
					temp[5]="新增";
				}
				if(temp[5].equals("修改")){
					try {
						String username = name.getText();
						for(int i=0;i<value.length;i++){
							for(int j=0;j<value[i].length;j++){
								if(value[i][0].equals(username)){
									table.setValueAt(username, row, 0);
									table.setValueAt(tel.getText(), row, 1);
									table.setValueAt(sex, row, 2);
									table.setValueAt(math.getText(), row, 3);
									table.setValueAt(english.getText(), row, 4);
									value[i][0]=name.getText();
									value[i][1]=tel.getText();
									value[i][2]=sex;
									value[i][3]=math.getText();
									value[i][4]=english.getText();
									row++;
									break;
								}
							}
						}
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "系统繁忙");
					}
					
				}
				if(temp[5].equals("新增")){
					fos.write(b, 0, b.length);
					dispose();
					new StudentWork();
					fos.close();
				}else {
					String valueString="";
 					for(int i=0;i<value.length;i++){
						for(int j=0;j<value[i].length;j++){
							if(j==value[i].length-1){
								valueString+=value[i][j]+";";
							}else {
								valueString+=value[i][j]+",";
							}
						}
					}
					File file1 = new File("timework.txt");
					try {
						FileOutputStream fos1 = new FileOutputStream(file1);
						byte b1[]=valueString.getBytes();
						fos1.write(b1, 0, b1.length);
						dispose();
						new StudentWork();
						fos1.close();
					}catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}else if (e.getSource()==close) {
			System.exit(0);
		}else if (e.getSource()==update) {
			int index=table.getSelectedRow();
			name.setText(data[index][0]);
			tel.setText(data[index][1]);
			if(data[index][2].equals("男")){
				man.setSelected(true);
			}else {
				weman.setSelected(true);
			}
			math.setText(data[index][3]);
			english.setText(data[index][4]);
			temp[0]=data[index][0];
			temp[1]=data[index][1];
			temp[2]=data[index][2];
			temp[3]=data[index][3];
			temp[4]=data[index][4];
			temp[5]="修改";
		}else if (e.getSource()==delete) {
			int index=table.getSelectedRow();
			String string = "";
			try {
				for(int i=0;i<value.length;i++){
					for(int j=0;j<value[i].length;j++){
						if(value[i][0].equals(data[index][0])){
							value[i][0].replace(data[index][0], "");
							value[i][1].replace(data[index][1], "");
							value[i][2].replace(data[index][2], "");
							value[i][3].replace(data[index][3], "");
							value[i][4].replace(data[index][4], "");
							value[i][5].replace(data[index][5]+";","");
							table.setValueAt("", index, 0);
							table.setValueAt("", index, 1);
							table.setValueAt("", index, 2);
							table.setValueAt("", index, 3);
							table.setValueAt("", index, 4);
							table.setValueAt("", index, 5);
							row++;
							continue;
						}
					}
				}
				for(int i=0;i<value.length;i++){
					for(int j=0;j<value[i].length;j++){
						if(i!=index){
							if(j==value[i].length-1){
								string+=value[i][j]+";";
							}else {
								string+=value[i][j]+",";
							}
						}
					}
				}
				File file = new File("timework.txt");
				try {
					FileOutputStream fos = new FileOutputStream(file);
					System.out.println("string="+string);
					byte b[]=string.getBytes();
					fos.write(b, 0, b.length);
					dispose();
					fos.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, "系统繁忙！");
			}
			new StudentWork();
		}else if (e.getSource()==timein) {
			String valueString="";
			for(int i=0;i<value.length;i++){
				for(int j=0;j<value[i].length;j++){
					if(j==value[i].length-1){
						valueString+=(Integer.parseInt(value[i][3])+Integer.parseInt(value[i][4]))+";";
					}else {
						valueString+=value[i][j]+",";
					}
				}
			}
			File file1 = new File("timework.txt");
			try {
				FileOutputStream fos1 = new FileOutputStream(file1);
				byte b1[]=valueString.getBytes();
				fos1.write(b1, 0, b1.length);
				dispose();
				new StudentWork();
				fos1.close();
			}catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
}
