﻿package T6;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel title,username,studentid;
	JTextField user;
	JPasswordField passwordField;
	JButton login,register;
	JPanel panel;
	public login() {
		setTitle("用户登录");
		
		panel = new JPanel(null);
		
		title = new JLabel("考勤人员登录");
		title.setBounds(100, 20, 100, 30);
		panel.add(title);
		
		username = new JLabel("姓名：");
		username.setBounds(30, 70, 60, 30);
		panel.add(username);
		
		user = new JTextField();
		user.setBounds(90,  70, 150, 30);
		panel.add(user);
		
		studentid = new JLabel("学号：");
		studentid.setBounds(30, 120,60, 30);
		panel.add(studentid);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(90, 120, 150, 30);
		panel.add(passwordField);
		
		login = new JButton("登录");
		login.setBounds(50, 180, 80, 30);
		panel.add(login);
		
		register = new JButton("注册");
		register.setBounds(140, 180, 80, 30);
		panel.add(register);
		
		add(panel);
		
		login.addActionListener(this);
		register.addActionListener(this);
		setSize(300,300);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new login();
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==login){
			dispose();
			new StudentWork();
		}else if(e.getSource()==register){
			dispose();
			JOptionPane.showMessageDialog(null, "欢迎注册考勤系统\n请在界面的上方填写资料注册","考勤注册",JOptionPane.INFORMATION_MESSAGE);
			new StudentWork();
		}
		
	}
	
	
	
}
