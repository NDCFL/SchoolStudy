package T6;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;
import java.util.Date;

public class Birthday extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTable table;
	JScrollPane js;
	JButton bu,buto,close,update,delete,timein,closeclass;
	JLabel lb1,lb2,lbname,lbbirthday,lbsex,lbhobit,lbphone,lbtitle,lbxinge;
	JTextField text,name,birthday,hobit,phone,xinge;
	JRadioButton man,weman;
	JTableHeader head;
	ButtonGroup bg;
	JPanel panel;
	String title[]={"姓名","性别","生日","爱好","联系方式","性格特点"};
	String data[][]=new String[90][6];
	String value[][];
	String temp[]= new String[6];
	static int row=0;
	@SuppressWarnings("deprecation")
	public Birthday() {
		setTitle("好友信息管理");
		readfile();
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image image = toolkit.getImage("281128.jpg");
		setIconImage(image);
		//界面的控件布局
		panel = new JPanel(null);
		table = new JTable(data,title);
		table.setBounds(0, 50, 500, 300);
		table.setRowHeight(30);
		table.setFont(new Font("楷体",Font.BOLD,16));
		
		//滚动面板
		js = new JScrollPane(table);
		js.setBounds(0,50,580, 292);
		
		panel.add(js);
		
		lb1 = new JLabel("好友信息管理");
		lb1.setBounds(220, 10, 200, 30);
		lb1.setFont(new Font("楷体",Font.BOLD,24));
		panel.add(lb1);
		
		lbtitle = new JLabel("好友新增");
		lbtitle.setBounds(650, 50, 80, 30);
		panel.add(lbtitle);
		
		lbname = new JLabel("姓名：");
		lbname.setBounds(600, 90, 50, 30);
		panel.add(lbname);
		
		name = new JTextField();
		name.setBounds(650, 90, 120, 30);
		panel.add(name);
		
		
		lbsex = new JLabel("性别：");
		lbsex.setBounds(600, 130, 50, 30);
		panel.add(lbsex);
		
		man = new JRadioButton("男",true);
		man.setBounds(650, 130, 50, 30);
		panel.add(man);
		
		weman = new JRadioButton("女",false);
		weman.setBounds(720, 130, 40, 30);
		panel.add(weman);
		
		bg = new ButtonGroup();
		bg.add(man);
		bg.add(weman);
		
		lbbirthday = new JLabel("生日：");
		lbbirthday.setBounds(600, 170, 50, 30);
		panel.add(lbbirthday);
		
		birthday = new JTextField();
		birthday.setBounds(650, 170, 120, 30);
		panel.add(birthday);
		
		lbhobit = new JLabel("爱好：");
		lbhobit.setBounds(600, 220, 60, 30);
		panel.add(lbhobit);
		
		hobit = new JTextField();
		hobit.setBounds(650, 220, 120, 30);
		panel.add(hobit);
		
		lbphone = new JLabel("Tel");
		lbphone.setBounds(600, 270, 60, 30);
		panel.add(lbphone);
		
		phone = new JTextField();
		phone.setBounds(650, 270, 120, 30);
		panel.add(phone);
		
		lbxinge = new JLabel("性格");
		lbxinge.setBounds(600, 320, 60, 30);
		panel.add(lbxinge);
		
		xinge = new JTextField();
		xinge.setBounds(650, 320, 120, 30);
		panel.add(xinge);
		
		buto = new JButton("新增/修改");
		buto.setBounds(30, 400, 100, 30);
		panel.add(buto);

		bu = new JButton("查找");
		bu.setBounds(470, 400, 80, 30);
		panel.add(bu);
		
		update = new JButton("修改");
		update.setBounds(330, 400, 80, 30);
		panel.add(update);
		
		delete = new JButton("删除");
		delete.setBounds(190, 400, 80, 30);
		panel.add(delete);
		
		timein = new JButton("关闭程序");
		timein.setBounds(600, 400, 120, 30);
		panel.add(timein);
		
		
		delete.addActionListener(this);
		update.addActionListener(this);
		bu.addActionListener(this);
		buto.addActionListener(this);
		timein.addActionListener(this);
		add(panel);
		setSize(800, 500);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new Birthday();
	}
	public void readfile(){
		int mouth = new Date().getMonth()+1;
		int day = new Date().getDate();
		try {
			File file = new File("friend.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String string = "";
			String str="";
			String birthday[]={};
			while ((string=br.readLine())!=null) {
				str+=string+";";
				birthday = str.split(";");
			}
			value = new String[birthday.length][6];
			for(int i=0;i<birthday.length;i++){
				try {
					value[i]=birthday[i].split(",");
					data[i]=birthday[i].split(",");
					String friend = data[i][2];
					int friendmongth = Integer.parseInt(friend.substring(5, 7));
					int friendday = Integer.parseInt(friend.substring(8, 10));
					if(friendmongth==mouth && friendday==day){
						JOptionPane.showMessageDialog(this, "你的好友"+data[i][0]+"今天生日");
					}
					System.out.println(friendmongth+";"+friendday);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(this, "系统繁忙，请稍后在试");
					return;
				}
			}
			br.close();
			file=null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bu){
			String nameid = name.getText();
			for(int i=0;i<value.length;i++){
				for(int j=0;j<value[i].length;j++){
					if(value[i][0].equals(nameid)){
						row++;
						table.setRowSelectionInterval(i,i);
						JOptionPane.showMessageDialog(this, "查询成功，已经为你高亮显示");
						return;
					}else if (value[i][1].equals(birthday.getText())) {
						row++;
						table.setRowSelectionInterval(i,i);
						JOptionPane.showMessageDialog(this, "查询成功，已经为你高亮显示");
						return;
					}
				}
			}
			JOptionPane.showMessageDialog(this, "无此人");
			return;
		}else if(e.getSource()==buto){
			if(name.getText().equals("")){
				JOptionPane.showMessageDialog(this, "姓名为空！");
				return;
			}else if (birthday.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "生日不能为空！");
				return;
			}else if (hobit.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "爱好不能为空！");
				return;
			}else if (phone.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "联系方式不能为空！");
				return;
			}else if (xinge.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "性格不能为空！");
				return;
			}else if (birthday.getText().length()!=10) {
				JOptionPane.showMessageDialog(this, "生日格式错误，如：1997-12-20！");
				return;
			}
			File file = new File("friend.txt");
			try {
				FileOutputStream fos = new FileOutputStream(file,true);
				String sex="";
				if(man.isSelected()){
					sex="男";
				}else {
					sex="女";
				}
				String string = name.getText()+","+sex+","+birthday.getText()+","+hobit.getText()+","+phone.getText()+","+xinge.getText()+";";
				byte b[]=string.getBytes();
				if(temp[5]==null || temp[5].equals("")){
					temp[5]="新增";
				}
				if(temp[5].equals("修改")){
					try {
						String username = name.getText();
						for(int i=0;i<value.length;i++){
							for(int j=0;j<value[i].length;j++){
								if(value[i][0].equals(username)){
									table.setValueAt(username, row, 0);
									table.setValueAt(birthday.getText(), row, 1);
									table.setValueAt(sex, row, 2);
									table.setValueAt(hobit.getText(), row, 3);
									table.setValueAt(phone.getText(), row, 4);
									value[i][0]=name.getText();
									value[i][1]=birthday.getText();
									value[i][2]=sex;
									value[i][3]=hobit.getText();
									value[i][4]=phone.getText();
									row++;
									break;
								}
							}
						}
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "系统繁忙");
					}
					
				}
				if(temp[5].equals("新增")){
					fos.write(b, 0, b.length);
					dispose();
					new Birthday();
					fos.close();
				}else {
					String valueString="";
 					for(int i=0;i<value.length;i++){
						for(int j=0;j<value[i].length;j++){
							if(j==value[i].length-1){
								valueString+=value[i][j]+";";
							}else {
								valueString+=value[i][j]+",";
							}
						}
					}
					File file1 = new File("friend.txt");
					try {
						FileOutputStream fos1 = new FileOutputStream(file1);
						byte b1[]=valueString.getBytes();
						fos1.write(b1, 0, b1.length);
						dispose();
						new Birthday();
						fos1.close();
					}catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}else if (e.getSource()==close) {
			System.exit(0);
		}else if (e.getSource()==update) {
			int index=table.getSelectedRow();
			if(index==-1){
				JOptionPane.showMessageDialog(null, "还未选择所要修改的好友");
				return;
			}
			name.setText(data[index][0]);
			if(data[index][1].equals("男")){
				man.setSelected(true);
			}else {
				weman.setSelected(true);
			}
			birthday.setText(data[index][2]);
			hobit.setText(data[index][3]);
			phone.setText(data[index][4]);
			xinge.setText(data[index][5]);
			temp[0]=data[index][0];
			temp[1]=data[index][1];
			temp[2]=data[index][2];
			temp[3]=data[index][3];
			temp[4]=data[index][4];
			temp[5]="修改";
		}else if (e.getSource()==delete) {
			int index=table.getSelectedRow();
			String string = "";
			try {
				for(int i=0;i<value.length;i++){
					for(int j=0;j<value[i].length;j++){
						if(value[i][0].equals(data[index][0])){
							value[i][0].replace(data[index][0], "");
							value[i][1].replace(data[index][1], "");
							value[i][2].replace(data[index][2], "");
							value[i][3].replace(data[index][3], "");
							value[i][4].replace(data[index][4], "");
							value[i][5].replace(data[index][5]+";","");
							table.setValueAt("", index, 0);
							table.setValueAt("", index, 1);
							table.setValueAt("", index, 2);
							table.setValueAt("", index, 3);
							table.setValueAt("", index, 4);
							table.setValueAt("", index, 5);
							row++;
							continue;
						}
					}
				}
				for(int i=0;i<value.length;i++){
					for(int j=0;j<value[i].length;j++){
						if(i!=index){
							if(j==value[i].length-1){
								string+=value[i][j]+";";
							}else {
								string+=value[i][j]+",";
							}
						}
					}
				}
				File file = new File("friend.txt");
				try {
					FileOutputStream fos = new FileOutputStream(file);
					System.out.println("string="+string);
					byte b[]=string.getBytes();
					fos.write(b, 0, b.length);
					dispose();
					fos.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, "系统繁忙！");
			}
			new Birthday();
		}else if (e.getSource()==timein) {
			String valueString="";
			for(int i=0;i<value.length;i++){
				for(int j=0;j<value[i].length;j++){
					if(j==value[i].length-1){
						valueString+=(Integer.parseInt(value[i][3])+Integer.parseInt(value[i][4]))+";";
					}else {
						valueString+=value[i][j]+",";
					}
				}
			}
			File file1 = new File("friend.txt");
			try {
				FileOutputStream fos1 = new FileOutputStream(file1);
				byte b1[]=valueString.getBytes();
				fos1.write(b1, 0, b1.length);
				dispose();
				new Birthday();
				fos1.close();
			}catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
}
